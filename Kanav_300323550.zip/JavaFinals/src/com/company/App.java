/*
 * Created by JFormDesigner on Sat Aug 08 09:00:36 PDT 2020
 */

package com.company;

import java.awt.event.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import com.mysql.cj.x.protobuf.MysqlxCrud;
import net.miginfocom.swing.*;

/**
 * @author unknown
 */
public class App extends JFrame {
    static ArrayList<Savings> savingsArray=new ArrayList<Savings>();
    public static DefaultTableModel datamodel,interestmodel;
    public static String numberOld=null;
    int rowcount=0;
    public App() throws SQLException {
        initComponents();
        Initialise();
    }
    private void Initialise() throws SQLException {
        CustTSavingsComboBox.addItem("Savings-Regular");
        CustTSavingsComboBox.addItem("Savings-Deluxe");
        DataDispaly();
        InterestDispaly();
    }
    public DefaultTableModel getDataModal(){
        return datamodel;
    }
    public int getRowAfter(){
        return rowcount+1;
    }
    public DefaultTableModel AddMouseClicked(MouseEvent e) throws SQLException {
        String name=CustNameText.getText();
        String number=CustNumberText.getText();
        String savings=CustTSavingsComboBox.getSelectedItem().toString();
        int years=0;
        double deposit=0;
        try {
            deposit=Double.valueOf(CustIDepositText.getText());

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null,"Deposit must be a Double value!!");
            return datamodel;

        }
        try {
            years=Integer.valueOf(CustYearsText.getText());
        } catch (Exception et) {
            JOptionPane.showMessageDialog(null,"Years must be a Integer value!!");
            return datamodel;
        }
        if (savings.equals("Savings-Regular")) {
            Savings customer=new Regular(number,name,deposit,years,savings);
            savingsArray.add(customer);
        }
        if (savings.equals("Savings-Deluxe")) {
            Savings customer=new Deluxe(number,name,deposit,years,savings);
            savingsArray.add(customer);
        }
        ResultSet rs=Main.statement.executeQuery("Select * from savingstable where custno='"+number+"'");
        rs.next();

        if(rs.getRow()==0){
            Main.statement.execute("INSERT into savingstable (custno,custname,cdep,nyears,savtype) values ('" +number+ "','" +
                    name+ "','" +deposit+ "','"+years+"','"+savings+"')");
            JOptionPane.showMessageDialog(null,"Data Added");
            Refresh();
            rowcount=getDataModal().getRowCount();
        }
        else{
            JOptionPane.showMessageDialog(null,"Customer no "+number+" already exists!!");
        }
        return datamodel;
    }

    private void Validation(){
        String name=CustNameText.getText();
        String number=CustNumberText.getText();
        String savings=CustTSavingsComboBox.getSelectedItem().toString();
        try {
            double deposit=Double.valueOf(CustIDepositText.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null,"Deposit must be a Double value!!");

        }
        try {
            int years=Integer.valueOf(CustYearsText.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null,"Years must be a Integer value!!");
        }
    }

    public void DataDispaly() throws SQLException {
        datamodel=new DefaultTableModel();
        datamodel.addColumn("Number");
        datamodel.addColumn("Name");
        datamodel.addColumn("Deposit");
        datamodel.addColumn("Years");
        datamodel.addColumn("Type of Savings");
        dataTable.setModel(datamodel);
        ResultSet rs= Main.statement.executeQuery("SELECT * from savingsTable");
        while (rs.next()){
            Object row[]={rs.getString("custno"),rs.getString("custname")
                    ,rs.getString("cdep"),rs.getString("nyears"),rs.getString("savtype")};
            datamodel.addRow(row);
        }
        rowcount=getDataModal().getRowCount();
    }

    public void InterestDispaly() throws SQLException {
        interestmodel=new DefaultTableModel();
        interestmodel.addColumn("Year");
        interestmodel.addColumn("Starting");
        interestmodel.addColumn("Interest");
        interestmodel.addColumn("Ending Value");


        if(numberOld!=null){
            int years=Integer.valueOf(datamodel.getValueAt(dataTable.getSelectedRow(),3).toString());
            double deposit=Double.valueOf(datamodel.getValueAt(dataTable.getSelectedRow(),2).toString());
            double interest,starting=deposit,ending,interestpercent=0;

            if(datamodel.getValueAt(dataTable.getSelectedRow(), 4).toString().equals("Savings-Regular")){
                interestpercent=.1;
            }
            if(datamodel.getValueAt(dataTable.getSelectedRow(), 4).toString().equals("Savings-Deluxe")){
                interestpercent=.15;
            }
            for(int i=1;i<=years;i++){
                interest=starting*interestpercent;

                ending=starting+interest;

                Object row[]={i,starting,interest,ending};
                interestmodel.addRow(row);
                starting=ending;
            }
        }
        interestTable.setModel(interestmodel);

    }

    private void dataTableMouseClicked(MouseEvent e) throws SQLException {
        CustNumberText.setText(datamodel.getValueAt(dataTable.getSelectedRow(),0).toString());
        CustNameText.setText(datamodel.getValueAt(dataTable.getSelectedRow(),1).toString());
        CustIDepositText.setText(datamodel.getValueAt(dataTable.getSelectedRow(),2).toString());
        CustYearsText.setText(datamodel.getValueAt(dataTable.getSelectedRow(),3).toString());
        CustTSavingsComboBox.setSelectedItem(datamodel.getValueAt(dataTable.getSelectedRow(),4).toString());
        numberOld=datamodel.getValueAt(dataTable.getSelectedRow(),0).toString();
        InterestDispaly();
    }

    private void EditMouseClicked(MouseEvent e) throws SQLException {
        String name=CustNameText.getText();
        String number=CustNumberText.getText();
        String savings=CustTSavingsComboBox.getSelectedItem().toString();
        int years=0;
        double deposit=0;
        try {
            deposit=Double.valueOf(CustIDepositText.getText());

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null,"Deposit must be a Double value!!");
            return;

        }
        try {
            years=Integer.valueOf(CustYearsText.getText());
        } catch (Exception et) {
            JOptionPane.showMessageDialog(null,"Years must be a Integer value!!");
            return;
        }
        if (savings.equals("Savings-Regular")) {
            Savings customer=new Regular(number,name,deposit,years,savings);
            savingsArray.add(customer);
        }
        if (savings.equals("Savings-Deluxe")) {
            Savings customer=new Deluxe(number,name,deposit,years,savings);
            savingsArray.add(customer);
        }
        ResultSet rs=Main.statement.executeQuery("Select * from savingstable where custno='"+number+"'");
        rs.next();

        if(rs.getRow()!=0){
            Main.statement.execute("UPDATE savingstable set custno'" +number+ "',custname='" +
                    name+ "',cdep='" +deposit+ "',nyears='"+years+"',savtype='"+savings+"' where custno='"+numberOld+"'");
            JOptionPane.showMessageDialog(null,"Data Updated");
            Refresh();
        }
        else{
            JOptionPane.showMessageDialog(null,"Error!!");
        }
    }

    public DefaultTableModel DeleteMouseClicked(MouseEvent e) throws SQLException {
        String number=CustNumberText.getText();
        ResultSet rs=Main.statement.executeQuery("Select * from savingstable where custno='"+number+"'");
        rs.next();

        if(rs.getRow()!=0){
            Main.statement.execute("DELETE FROM savingstable WHERE custno='" + number + "'");
            JOptionPane.showMessageDialog(null,"Data Deleted");
            Refresh();
        }
        else{
            JOptionPane.showMessageDialog(null,"Error!! Customer no doesnot exists");
        }
        return datamodel;
    }
    private void Refresh() throws SQLException {
        datamodel.setRowCount(0);
        DataDispaly();
    }
    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner Evaluation license - unknown
        label1 = new JLabel();
        CustNumberText = new JTextField();
        label2 = new JLabel();
        CustNameText = new JTextField();
        label3 = new JLabel();
        CustIDepositText = new JTextField();
        label4 = new JLabel();
        CustYearsText = new JTextField();
        label5 = new JLabel();
        CustTSavingsComboBox = new JComboBox();
        scrollPane1 = new JScrollPane();
        dataTable = new JTable();
        scrollPane2 = new JScrollPane();
        interestTable = new JTable();
        button1 = new JButton();
        button3 = new JButton();
        button4 = new JButton();

        //======== this ========
        var contentPane = getContentPane();
        contentPane.setLayout(new MigLayout(
                "hidemode 3",
                // columns
                "[fill]" +
                        "[fill]" +
                        "[fill]" +
                        "[fill]" +
                        "[fill]" +
                        "[fill]" +
                        "[fill]" +
                        "[fill]" +
                        "[fill]" +
                        "[fill]" +
                        "[fill]" +
                        "[fill]" +
                        "[fill]" +
                        "[fill]" +
                        "[fill]" +
                        "[fill]" +
                        "[fill]" +
                        "[fill]" +
                        "[fill]" +
                        "[fill]" +
                        "[fill]" +
                        "[fill]" +
                        "[fill]" +
                        "[fill]" +
                        "[fill]" +
                        "[fill]",
                // rows
                "[]" +
                        "[]" +
                        "[]" +
                        "[]" +
                        "[]" +
                        "[]" +
                        "[]" +
                        "[]" +
                        "[]" +
                        "[]" +
                        "[]" +
                        "[]" +
                        "[]" +
                        "[]" +
                        "[]" +
                        "[]" +
                        "[]" +
                        "[]" +
                        "[]" +
                        "[]" +
                        "[]"));

        //---- label1 ----
        label1.setText("Enter the Customer Number");
        contentPane.add(label1, "cell 0 0 6 1");
        contentPane.add(CustNumberText, "cell 7 0 19 1");

        //---- label2 ----
        label2.setText("Enter the Customer Name");
        contentPane.add(label2, "cell 0 1 6 1");
        contentPane.add(CustNameText, "cell 7 1 19 1");

        //---- label3 ----
        label3.setText("Enter the Initial Deposit");
        contentPane.add(label3, "cell 0 2 6 1");
        contentPane.add(CustIDepositText, "cell 7 2 19 1");

        //---- label4 ----
        label4.setText("Enter the no of years");
        contentPane.add(label4, "cell 0 3 6 1");
        contentPane.add(CustYearsText, "cell 7 3 19 1");

        //---- label5 ----
        label5.setText("Choose the type of Savings");
        contentPane.add(label5, "cell 0 4 6 1");
        contentPane.add(CustTSavingsComboBox, "cell 7 4 19 1");

        //======== scrollPane1 ========
        {

            //---- dataTable ----
            dataTable.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    try {
                        dataTableMouseClicked(e);
                    } catch (SQLException ex) {
                        ex.printStackTrace();
                    }
                }
            });
            scrollPane1.setViewportView(dataTable);
        }
        contentPane.add(scrollPane1, "cell 0 5 7 1");

        //======== scrollPane2 ========
        {
            scrollPane2.setViewportView(interestTable);
        }
        contentPane.add(scrollPane2, "cell 7 5 19 1");

        //---- button1 ----
        button1.setText("Add");
        button1.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                try {
                    AddMouseClicked(e);
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });
        contentPane.add(button1, "cell 0 8");

        //---- button3 ----
        button3.setText("Edit");
        button3.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                try {
                    EditMouseClicked(e);
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });
        contentPane.add(button3, "cell 2 8");

        //---- button4 ----
        button4.setText("Delete");
        button4.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                try {
                    DeleteMouseClicked(e);
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        });
        contentPane.add(button4, "cell 5 8");
        pack();
        setLocationRelativeTo(getOwner());
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner Evaluation license - unknown
    private JLabel label1;
    private JTextField CustNumberText;
    private JLabel label2;
    private JTextField CustNameText;
    private JLabel label3;
    private JTextField CustIDepositText;
    private JLabel label4;
    private JTextField CustYearsText;
    private JLabel label5;
    private JComboBox CustTSavingsComboBox;
    private JScrollPane scrollPane1;
    private JTable dataTable;
    private JScrollPane scrollPane2;
    private JTable interestTable;
    private JButton button1;
    private JButton button3;
    private JButton button4;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
}
