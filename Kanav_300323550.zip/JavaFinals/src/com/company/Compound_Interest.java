package com.company;

import java.sql.SQLException;

public interface Compound_Interest {
    public void generateTable() throws SQLException;
}
