package com.company;

import java.sql.SQLException;

public class Deluxe extends Savings implements Compound_Interest{

    public Deluxe(String number,String name,double deposit,int years, String type){
        super(number,name,deposit,years,type);
    }
    @Override
    public void generateTable() throws SQLException {
        Main.App.InterestDispaly();
    }
}
