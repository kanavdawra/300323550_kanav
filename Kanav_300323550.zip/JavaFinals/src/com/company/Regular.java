package com.company;

import java.sql.SQLException;

public class Regular extends Savings implements Compound_Interest{

    public Regular(String number,String name,double deposit,int years, String type){
        super(number,name,deposit,years,type);
    }
    public void generateTablet(){}
    @Override
    public void generateTable() throws SQLException {
     Main.App.InterestDispaly();
    }
}
