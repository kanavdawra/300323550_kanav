package com.company;

public class Savings {
    String custName,custNumber,typeOfSavings;
    double initialDeposit;
    int noOfYears;
   public Savings(String number,String name,double deposit,int years, String type){
       custName=name;
       custNumber=number;
       typeOfSavings=type;
       initialDeposit=deposit;
       noOfYears=years;
   }
}
